/function generate two-dimensional test set data

function generateTestSet(tcInput, tcOutput) {
  let testSet = [];
  for (let i = 0; i < tcInput.length; i++) {
    let testCase = { input: tcInput[i], output: tcOutput };
    testSet.push(testCase);
  }
  return testSet;
}