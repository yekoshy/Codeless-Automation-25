//function to type in field, field identified by ID

function typeInField(fieldId, fieldData) {
  let side = document.getElementById(fieldId);
  console.log(document.getElementById(fieldId).value);
  side.value = fieldData;
  console.log(side.value);
  console.log(`Filled field ${fieldId} with ${fieldData}`);
  console.assert(
    side.value == fieldData,
    `Expected: Field ${fieldId} should be filled with ${fieldData}, Actual: ${side.value}`
  );
}