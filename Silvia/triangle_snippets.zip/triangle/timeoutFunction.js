// timeout function
function timeoutCalled(myTimeout) {
  console.log("myTimeout");
}