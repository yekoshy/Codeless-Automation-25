// GUI Messages - from manual testing
const validResults = ["Equilateral", "Scalene", "Isosceles"];
const errorMessages = [
  "Error: Not a Triangle",
  "Error: Side 1 is missing",
  "Error: Side 2 is missing",
  "Error: Side 3 is missing",
  "Error: Side 1 is not a Number",
  "Error: Side 2 is not a Number",
  "Error: Side 3 is not a Number",
];

//my interface elements
// button
const buttonID = "identify-triangle-action"; // id of the button
// 3 input fields named side1, side2, side 3
// Result string div and p
const resultDisplayID = "triangle-type";
// canvas for visualisation
