//function to insert three values, click button and evaluate result
function checkTriangle(testCase) {
  console.log("testcase = " + testCase);
  for (let j = 0; j < 3; j++) {
    inputData = testCase[j];
    //console.log("input data: " + inputData);
    let inputId = "side" + (j + 1);
    console.log(inputId);
    typeInField(inputId, inputData);
  }
  clickButton(buttonID);
}