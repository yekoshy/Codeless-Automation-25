//function to run a test case set

function testTestCase(testCaseSet) {
  console.log(testCaseSet);
  for (let k = 0; k < testCaseSet.length; k++) {
    let testcase = testCaseSet[k].input;
    //console.log(`Is input an array? ${Array.isArray(testCaseSet[k].input)}`);
    let expectedResult = testCaseSet[k].output;

    console.log(`k = ${k}, input ${testcase}, expected ${expectedResult}`);
    checkTriangle(testcase);
    //wait before calling assert
    setTimeout(timeoutCalled, 3000);
    console.assert(
      document.getElementById(resultDisplayID).innerHTML === expectedResult,
      `Expected: Result should be ${expectedResult}, Actual: ${
        document.getElementById(resultDisplayID).innerText
      }`
    );
  }
}