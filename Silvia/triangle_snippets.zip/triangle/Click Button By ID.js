//function to click Button, identify button by id
function clickButton(buttonID) {
  document.getElementById(buttonID).click();
}