const testDataLarge = [
  { input: [49, 49, 49], output: "Equilateral" },
  { input: [49, 168, 168], output: "Isosceles" },
  { input: [1000, 1000, 1000], output: "Equilateral" },
];

const testDataVeryLarge = [
  { input: [1234567890, 1234567890, 1234567890], output: "Equilateral" },
  { input: [1234567890, 1234567890, 123456], output: "Isosceles" },
];

const testDataNan = [
  { input: [1, 1], output: "Error: Side 3 is missing" },
  { input: [4, -4, 4], output: "Error: Not a Triangle" },
  { input: [("a", 2, 3)], output: "Error: Side 1 is not a Number" },
  { input: [2, "b", 4], output: "Error: Side 2 is not a Number" },
  { input: [3, 4, "c"], output: "Error: Side 3 is not a Number" },
];
const testSetEqui = generateTestSet(testDataEqui, validResults[0]);
console.log(testSetEqui);
const testSetScalene = generateTestSet(testDataScalene, validResults[1]);
const testSetIso = generateTestSet(testDataIso, validResults[2]);
const testSetNaT = generateTestSet(testDataNAT, errorMessages[0]);
